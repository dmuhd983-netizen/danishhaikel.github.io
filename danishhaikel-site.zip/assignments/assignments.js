/*
  HOW TO ADD AN ASSIGNMENT
  ------------------------
  1. Copy one block below, paste it inside the [ ], and fill it in.
  2. "link" can be:
       a web link        "https://..."
       a file you upload "files/my-brief.pdf"   (put the file in the assignments/files folder)
       an HTML page      "files/my-brief.html"
  3. "due" is written as "YYYY-MM-DD". Leave it "" if there is no due date.
  4. Save, commit and push to GitHub. The site updates by itself.

  Example (copy this, remove the // at the start of each line):

  // {
  //   title: "Group 1 report framework",
  //   course: "Course code",
  //   group: "Group 1",
  //   due: "2026-11-28",
  //   link: "files/group-1-framework.html",
  //   note: "Read before our Thursday meeting"
  // },
*/

const ASSIGNMENTS = [

]
