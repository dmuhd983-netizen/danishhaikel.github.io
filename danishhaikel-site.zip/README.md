# danishhaikel.com

Personal website of Danish Haikel. Plain HTML and CSS, deployed on Cloudflare Pages from this repository.

## Folders

- `index.html` homepage
- `style.css` shared styles for every page
- `johor-atlas/` Johor Company Atlas
- `assignments/` assignment instructions page
  - `assignments.js` the list of assignments (edit this to add one)
  - `files/` put uploaded briefs here (PDF, HTML, DOCX)

## Add an assignment

1. Put the file in `assignments/files/` (skip this if you only have a web link).
2. Open `assignments/assignments.js` and add a block inside the `[ ]`:

```js
{
  title: "Group 1 report framework",
  course: "Course code",
  group: "Group 1",
  due: "2026-11-28",
  link: "files/group-1-framework.html",
  note: ""
},
```

3. Commit and push. Cloudflare Pages updates the site in about a minute.
